function ResourceHubPage() {
    return <section>This resource hub blog page is under development</section>
}
export default ResourceHubPage