function CaseStudiesPage() {
    return <section>This Case studies page is under development</section>
}
export default CaseStudiesPage