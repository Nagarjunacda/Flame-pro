import styles from '../filters.module.css'

function FiltersMweb({ filtersData }) {
    return <section></section>
}
export default FiltersMweb