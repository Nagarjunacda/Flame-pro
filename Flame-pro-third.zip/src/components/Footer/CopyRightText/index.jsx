import styles from '../footer.module.css'
function CopyRightText() {
    return <section className={styles.copyRightCont}>
        <p> © Copyright © 2023 - Flame Pro</p>
        <p>Designed and Developed by CDA</p>
    </section>
}
export default CopyRightText;